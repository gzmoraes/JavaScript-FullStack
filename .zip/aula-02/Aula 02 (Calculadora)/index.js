const Numero1 = prompt(`CALCULADORA
Digite um número:`);

const Numero2 = prompt(`CALCULADORA 
Digite um número:`);

let conta1 = parseFloat(Numero1);
let conta2 = parseFloat(Numero2);

alert(`Soma = ${conta1 + conta2} 
Multiplicação = ${conta1 * conta2} 
Divisão = ${conta1 / conta2} 
Subtração = ${conta1 - conta2}`);
