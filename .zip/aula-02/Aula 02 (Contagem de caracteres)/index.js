const frase = prompt("Escreva algo:")
let contagem

contagem = frase.length
alert(`sua frase contém ${contagem}`)