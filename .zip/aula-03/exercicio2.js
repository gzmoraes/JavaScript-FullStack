let numero = parseInt(prompt("FATORIAL\ndigite um numero"))
let fatorial = 1 

for(let i = 1; i <= numero; i++){
    fatorial *= i
}

alert(`o fatorial de ${numero} é ${fatorial}`)


    