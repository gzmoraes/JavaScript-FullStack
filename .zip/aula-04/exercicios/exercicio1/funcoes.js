export function dobro() {
  const num = parseFloat(prompt("Insira um numero"));
  let resposta = num * 2;
  alert(`o dobro deste numero é ${resposta}`);
}
