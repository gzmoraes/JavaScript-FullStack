import { dobro } from "../funcoes.js"

dobro()
