
export function subtrair(x,y){
    let subRes = x - y 
    alert (`${x} - ${y} = ${subRes}`)
}

export function somar(a,b){
    let somaRes = a + b
    alert (`${a} + ${b} = ${somaRes}`)
}


   