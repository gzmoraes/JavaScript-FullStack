import { ola } from "./ola";

ola()