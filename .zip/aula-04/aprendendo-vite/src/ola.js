export function ola(){
    alert("ola mundo")
}